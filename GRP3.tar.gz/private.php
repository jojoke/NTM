<!DOCTYPE HTML>
<html>

<head>
        <title>Private page</title>
        <meta charset="utf-8">
        <meta name="description" content="165c. uniques">
</head>

<body>
    <h1>Private page</h1>
	Bravo, vous avez atteint la page privée!

</body>
</html>
